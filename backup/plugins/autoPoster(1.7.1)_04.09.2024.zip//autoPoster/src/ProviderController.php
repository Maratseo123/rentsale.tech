<?php

/******************************************************************************
 *  
 *  PROJECT: Flynax Classifieds Software
 *  VERSION: 4.7.2
 *  LICENSE: RU70XA4A4YQ2 - https://www.flynax.ru/user-agreement.html
 *  PRODUCT: General Classifieds
 *  DOMAIN: heidenbauer.ru
 *  FILE: RLAUTOPOSTER.CLASS.PHP
 *  
 *  The software is a commercial product delivered under single, non-exclusive,
 *  non-transferable license for one domain or IP address. Therefore distribution,
 *  sale or transfer of the file in whole or in part without permission of Flynax
 *  respective owners is considered to be illegal and breach of Flynax License End
 *  User Agreement.
 *  
 *  You are not allowed to remove this information from the file without permission
 *  of Flynax respective owners.
 *  
 *  Flynax Classifieds Software 2023 | All copyrights reserved.
 *  
 *  https://www.flynax.ru
 ******************************************************************************/

namespace Autoposter;

use Autoposter\Providers;

class ProviderController
{
    /**
     * @var \rlDb
     */
    private $rlDb;

    /**
     * @var \rlValid
     */
    private $rlValid;

    /**
     * @var string - Current active provider
     */
    private $provider;

    /**
     * @var array - List of all available providers
     */
    private $available_providers;

    /**
     * ProviderController constructor.
     *
     * @param string $provider_name - Set provider as active for this instance
     */
    public function __construct($provider_name)
    {
        $this->rlDb = AutoPosterContainer::getObject('rlDb');
        $this->rlValid = AutoPosterContainer::getObject('rlValid');
        $this->available_providers = array_keys(AutoPosterContainer::getConfig('configs')['modules']);
        return $this->setProvider($provider_name) ? true : false;
    }

    /**
     * Provider setter
     *
     * @param  string $name - Provider name: {facebook, twitter}
     * @return bool         -
     */
    public function setProvider($name)
    {
        $provider = strtolower($name);
        if (!in_array($provider, $this->available_providers)) {
            return false;
        }
        $class = '\\Autoposter\\Providers\\' . ucfirst($provider);

        return class_exists($class) ? $this->provider = new $class() : false;
    }

    /**
     * Provider getter
     *
     * @return string - Active provider
     */
    public function getProvider()
    {
        return $this->provider;
    }
}
